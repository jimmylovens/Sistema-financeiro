import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { 
  Home, 
  CreditCard, 
  TrendingUp, 
  PieChart, 
  Settings, 
  Plus,
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
  Target,
  Calendar,
  Loader2
} from 'lucide-react'
import ApiService from './services/api.js'
import './App.css'

function App() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  
  // Estados para dados
  const [dashboardData, setDashboardData] = useState(null)
  const [transactions, setTransactions] = useState([])
  const [categories, setCategories] = useState([])
  
  // Estados para modal de nova transação
  const [showNewTransactionModal, setShowNewTransactionModal] = useState(false)
  const [newTransaction, setNewTransaction] = useState({
    description: '',
    amount: '',
    type: 'despesa',
    category_id: '',
    date: new Date().toISOString().split('T')[0]
  })

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'transacoes', label: 'Transações', icon: CreditCard },
    { id: 'relatorios', label: 'Relatórios', icon: TrendingUp },
    { id: 'categorias', label: 'Categorias', icon: PieChart },
    { id: 'configuracoes', label: 'Configurações', icon: Settings }
  ]

  // Carregar dados iniciais
  useEffect(() => {
    loadInitialData()
  }, [])

  // Recarregar dados quando mudar de aba
  useEffect(() => {
    if (activeTab === 'dashboard') {
      loadDashboardData()
    } else if (activeTab === 'transacoes') {
      loadTransactions()
    }
  }, [activeTab])

  const loadInitialData = async () => {
    try {
      setLoading(true)
      setError(null)

      // Verificar se API está funcionando
      await ApiService.healthCheck()

      // Carregar categorias
      const categoriesData = await ApiService.getCategories()
      
      // Se não há categorias, inicializar as padrão
      if (categoriesData.length === 0) {
        await ApiService.initializeDefaultCategories()
        const newCategoriesData = await ApiService.getCategories()
        setCategories(newCategoriesData)
      } else {
        setCategories(categoriesData)
      }

      // Carregar dados do dashboard
      await loadDashboardData()
      
    } catch (err) {
      console.error('Erro ao carregar dados iniciais:', err)
      setError('Erro ao conectar com o servidor. Verifique se a API está rodando.')
    } finally {
      setLoading(false)
    }
  }

  const loadDashboardData = async () => {
    try {
      const data = await ApiService.getDashboardSummary()
      setDashboardData(data)
    } catch (err) {
      console.error('Erro ao carregar dashboard:', err)
      setError('Erro ao carregar dados do dashboard')
    }
  }

  const loadTransactions = async () => {
    try {
      const data = await ApiService.getTransactions({ per_page: 20 })
      setTransactions(data.transactions || [])
    } catch (err) {
      console.error('Erro ao carregar transações:', err)
      setError('Erro ao carregar transações')
    }
  }

  const handleCreateTransaction = async () => {
    try {
      if (!newTransaction.description || !newTransaction.amount || !newTransaction.category_id) {
        alert('Preencha todos os campos obrigatórios')
        return
      }

      await ApiService.createTransaction({
        ...newTransaction,
        amount: parseFloat(newTransaction.amount)
      })

      // Resetar formulário
      setNewTransaction({
        description: '',
        amount: '',
        type: 'despesa',
        category_id: '',
        date: new Date().toISOString().split('T')[0]
      })

      setShowNewTransactionModal(false)

      // Recarregar dados
      if (activeTab === 'dashboard') {
        loadDashboardData()
      } else if (activeTab === 'transacoes') {
        loadTransactions()
      }

      alert('Transação criada com sucesso!')

    } catch (err) {
      console.error('Erro ao criar transação:', err)
      alert('Erro ao criar transação: ' + err.message)
    }
  }

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value || 0)
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('pt-BR')
  }

  const getCategoryById = (id) => {
    return categories.find(cat => cat.id === id)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" />
          <p>Carregando sistema financeiro...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-red-500 text-2xl">⚠️</span>
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Erro de Conexão</h3>
          <p className="text-gray-500 mb-4">{error}</p>
          <Button onClick={loadInitialData}>Tentar Novamente</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'w-64' : 'w-16'} bg-white shadow-lg transition-all duration-300 flex flex-col`}>
        <div className="p-6 border-b">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            {sidebarOpen && (
              <div>
                <h1 className="text-xl font-bold text-gray-900">FinanceControl</h1>
                <p className="text-sm text-gray-500">Controle Financeiro</p>
              </div>
            )}
          </div>
        </div>

        <nav className="flex-1 p-4">
          <ul className="space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon
              return (
                <li key={item.id}>
                  <button
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                      activeTab === item.id
                        ? 'bg-emerald-100 text-emerald-700'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    {sidebarOpen && <span className="font-medium">{item.label}</span>}
                  </button>
                </li>
              )
            })}
          </ul>
        </nav>

        <div className="p-4 border-t">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="w-full"
          >
            {sidebarOpen ? '←' : '→'}
          </Button>
        </div>
      </div>

      {/* Conteúdo Principal */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white shadow-sm border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">
                {menuItems.find(item => item.id === activeTab)?.label || 'Dashboard'}
              </h2>
              <p className="text-gray-500">Bem-vindo ao seu controle financeiro</p>
            </div>
            <div className="flex items-center space-x-4">
              <Dialog open={showNewTransactionModal} onOpenChange={setShowNewTransactionModal}>
                <DialogTrigger asChild>
                  <Button className="bg-emerald-500 hover:bg-emerald-600">
                    <Plus className="w-4 h-4 mr-2" />
                    Nova Transação
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Nova Transação</DialogTitle>
                    <DialogDescription>
                      Adicione uma nova receita ou despesa ao seu controle financeiro.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="description">Descrição</Label>
                      <Input
                        id="description"
                        value={newTransaction.description}
                        onChange={(e) => setNewTransaction({...newTransaction, description: e.target.value})}
                        placeholder="Ex: Supermercado, Salário..."
                      />
                    </div>
                    <div>
                      <Label htmlFor="amount">Valor</Label>
                      <Input
                        id="amount"
                        type="number"
                        step="0.01"
                        value={newTransaction.amount}
                        onChange={(e) => setNewTransaction({...newTransaction, amount: e.target.value})}
                        placeholder="0,00"
                      />
                    </div>
                    <div>
                      <Label htmlFor="type">Tipo</Label>
                      <Select value={newTransaction.type} onValueChange={(value) => setNewTransaction({...newTransaction, type: value})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="receita">Receita</SelectItem>
                          <SelectItem value="despesa">Despesa</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="category">Categoria</Label>
                      <Select value={newTransaction.category_id} onValueChange={(value) => setNewTransaction({...newTransaction, category_id: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione uma categoria" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories
                            .filter(cat => cat.type === newTransaction.type)
                            .map(category => (
                              <SelectItem key={category.id} value={category.id.toString()}>
                                {category.name}
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="date">Data</Label>
                      <Input
                        id="date"
                        type="date"
                        value={newTransaction.date}
                        onChange={(e) => setNewTransaction({...newTransaction, date: e.target.value})}
                      />
                    </div>
                    <div className="flex space-x-2">
                      <Button onClick={handleCreateTransaction} className="flex-1">
                        Criar Transação
                      </Button>
                      <Button variant="outline" onClick={() => setShowNewTransactionModal(false)}>
                        Cancelar
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </header>

        {/* Conteúdo */}
        <main className="flex-1 overflow-auto p-6">
          {activeTab === 'dashboard' && dashboardData && (
            <div className="space-y-6">
              {/* Cards de Resumo */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Saldo Atual</CardTitle>
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-emerald-600">
                      {formatCurrency(dashboardData.summary.saldo)}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Período: {dashboardData.period.month}/{dashboardData.period.year}
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Receitas</CardTitle>
                    <ArrowUpRight className="h-4 w-4 text-green-500" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-600">
                      {formatCurrency(dashboardData.summary.receitas)}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Este mês
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Despesas</CardTitle>
                    <ArrowDownRight className="h-4 w-4 text-red-500" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-red-600">
                      {formatCurrency(dashboardData.summary.despesas)}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Este mês
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Economia</CardTitle>
                    <Target className="h-4 w-4 text-blue-500" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-blue-600">
                      {formatCurrency(dashboardData.summary.economia)}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Diferença receitas - despesas
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Transações Recentes */}
              <Card>
                <CardHeader>
                  <CardTitle>Transações Recentes</CardTitle>
                  <CardDescription>
                    Últimas movimentações registradas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {dashboardData.recent_transactions.length === 0 ? (
                      <p className="text-gray-500 text-center py-4">
                        Nenhuma transação encontrada. Adicione sua primeira transação!
                      </p>
                    ) : (
                      dashboardData.recent_transactions.map((transacao) => (
                        <div key={transacao.id} className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className={`w-2 h-2 rounded-full ${
                              transacao.type === 'receita' ? 'bg-green-500' : 'bg-red-500'
                            }`} />
                            <div>
                              <p className="text-sm font-medium">{transacao.description}</p>
                              <p className="text-xs text-gray-500">
                                {transacao.category?.name || 'Sem categoria'}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className={`text-sm font-medium ${
                              transacao.type === 'receita' ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {transacao.type === 'receita' ? '+' : '-'}{formatCurrency(Math.abs(transacao.amount))}
                            </p>
                            <p className="text-xs text-gray-500">{formatDate(transacao.date)}</p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === 'transacoes' && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Todas as Transações</CardTitle>
                  <CardDescription>
                    Gerencie suas receitas e despesas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {transactions.length === 0 ? (
                      <p className="text-gray-500 text-center py-8">
                        Nenhuma transação encontrada. Clique em "Nova Transação" para começar!
                      </p>
                    ) : (
                      transactions.map((transacao) => (
                        <div key={transacao.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-4">
                            <div className={`w-3 h-3 rounded-full ${
                              transacao.type === 'receita' ? 'bg-green-500' : 'bg-red-500'
                            }`} />
                            <div>
                              <p className="font-medium">{transacao.description}</p>
                              <div className="flex items-center space-x-2 text-sm text-gray-500">
                                <Badge variant="outline">
                                  {transacao.category?.name || 'Sem categoria'}
                                </Badge>
                                <span>•</span>
                                <span>{formatDate(transacao.date)}</span>
                              </div>
                            </div>
                          </div>
                          <div className={`text-lg font-semibold ${
                            transacao.type === 'receita' ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {transacao.type === 'receita' ? '+' : '-'}{formatCurrency(Math.abs(transacao.amount))}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab !== 'dashboard' && activeTab !== 'transacoes' && (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  {menuItems.find(item => item.id === activeTab)?.label}
                </h3>
                <p className="text-gray-500">Esta seção será implementada em breve</p>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}

export default App

