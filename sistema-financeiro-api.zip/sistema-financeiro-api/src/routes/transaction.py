from flask import Blueprint, request, jsonify
from datetime import datetime, date
from src.models.transaction import db, Transaction, Category, Goal
from sqlalchemy import func, extract

transaction_bp = Blueprint('transaction', __name__)

@transaction_bp.route('/transactions', methods=['GET'])
def get_transactions():
    """Listar todas as transações com filtros opcionais"""
    try:
        # Parâmetros de filtro
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        category_id = request.args.get('category_id', type=int)
        transaction_type = request.args.get('type')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')

        # Query base
        query = Transaction.query

        # Aplicar filtros
        if category_id:
            query = query.filter(Transaction.category_id == category_id)
        
        if transaction_type:
            query = query.filter(Transaction.type == transaction_type)
        
        if start_date:
            start_date_obj = datetime.strptime(start_date, '%Y-%m-%d').date()
            query = query.filter(Transaction.date >= start_date_obj)
        
        if end_date:
            end_date_obj = datetime.strptime(end_date, '%Y-%m-%d').date()
            query = query.filter(Transaction.date <= end_date_obj)

        # Ordenar por data (mais recente primeiro)
        query = query.order_by(Transaction.date.desc(), Transaction.created_at.desc())

        # Paginação
        transactions = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )

        return jsonify({
            'transactions': [t.to_dict() for t in transactions.items],
            'total': transactions.total,
            'pages': transactions.pages,
            'current_page': page,
            'per_page': per_page
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/transactions', methods=['POST'])
def create_transaction():
    """Criar nova transação"""
    try:
        data = request.get_json()

        # Validação dos dados obrigatórios
        required_fields = ['description', 'amount', 'type', 'category_id']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400

        # Validar tipo de transação
        if data['type'] not in ['receita', 'despesa']:
            return jsonify({'error': 'Tipo deve ser "receita" ou "despesa"'}), 400

        # Validar se categoria existe
        category = Category.query.get(data['category_id'])
        if not category:
            return jsonify({'error': 'Categoria não encontrada'}), 404

        # Processar data
        transaction_date = date.today()
        if 'date' in data and data['date']:
            try:
                transaction_date = datetime.strptime(data['date'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': 'Formato de data inválido. Use YYYY-MM-DD'}), 400

        # Criar transação
        transaction = Transaction(
            description=data['description'],
            amount=float(data['amount']),
            type=data['type'],
            category_id=data['category_id'],
            date=transaction_date
        )

        db.session.add(transaction)
        db.session.commit()

        return jsonify(transaction.to_dict()), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/transactions/<int:transaction_id>', methods=['GET'])
def get_transaction(transaction_id):
    """Obter transação específica"""
    try:
        transaction = Transaction.query.get_or_404(transaction_id)
        return jsonify(transaction.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/transactions/<int:transaction_id>', methods=['PUT'])
def update_transaction(transaction_id):
    """Atualizar transação"""
    try:
        transaction = Transaction.query.get_or_404(transaction_id)
        data = request.get_json()

        # Atualizar campos se fornecidos
        if 'description' in data:
            transaction.description = data['description']
        
        if 'amount' in data:
            transaction.amount = float(data['amount'])
        
        if 'type' in data:
            if data['type'] not in ['receita', 'despesa']:
                return jsonify({'error': 'Tipo deve ser "receita" ou "despesa"'}), 400
            transaction.type = data['type']
        
        if 'category_id' in data:
            category = Category.query.get(data['category_id'])
            if not category:
                return jsonify({'error': 'Categoria não encontrada'}), 404
            transaction.category_id = data['category_id']
        
        if 'date' in data and data['date']:
            try:
                transaction.date = datetime.strptime(data['date'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': 'Formato de data inválido. Use YYYY-MM-DD'}), 400

        transaction.updated_at = datetime.utcnow()
        db.session.commit()

        return jsonify(transaction.to_dict())

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/transactions/<int:transaction_id>', methods=['DELETE'])
def delete_transaction(transaction_id):
    """Deletar transação"""
    try:
        transaction = Transaction.query.get_or_404(transaction_id)
        db.session.delete(transaction)
        db.session.commit()
        return jsonify({'message': 'Transação deletada com sucesso'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/dashboard/summary', methods=['GET'])
def get_dashboard_summary():
    """Obter resumo para o dashboard"""
    try:
        # Parâmetros de período (padrão: mês atual)
        year = request.args.get('year', datetime.now().year, type=int)
        month = request.args.get('month', datetime.now().month, type=int)

        # Filtrar transações do período
        transactions = Transaction.query.filter(
            extract('year', Transaction.date) == year,
            extract('month', Transaction.date) == month
        ).all()

        # Calcular totais
        total_receitas = sum(t.amount for t in transactions if t.type == 'receita')
        total_despesas = sum(t.amount for t in transactions if t.type == 'despesa')
        saldo = total_receitas - total_despesas

        # Transações recentes (últimas 5)
        recent_transactions = Transaction.query.order_by(
            Transaction.date.desc(), 
            Transaction.created_at.desc()
        ).limit(5).all()

        # Resumo por categoria
        category_summary = db.session.query(
            Category.name,
            Category.color,
            func.sum(Transaction.amount).label('total')
        ).join(Transaction).filter(
            extract('year', Transaction.date) == year,
            extract('month', Transaction.date) == month
        ).group_by(Category.id).all()

        return jsonify({
            'period': {'year': year, 'month': month},
            'summary': {
                'saldo': saldo,
                'receitas': total_receitas,
                'despesas': total_despesas,
                'economia': saldo
            },
            'recent_transactions': [t.to_dict() for t in recent_transactions],
            'category_summary': [
                {'name': name, 'color': color, 'total': float(total)}
                for name, color, total in category_summary
            ]
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

