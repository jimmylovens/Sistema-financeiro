from flask import Blueprint, request, jsonify
from src.models.transaction import db, Category

category_bp = Blueprint('category', __name__)

@category_bp.route('/categories', methods=['GET'])
def get_categories():
    """Listar todas as categorias"""
    try:
        category_type = request.args.get('type')  # 'receita' ou 'despesa'
        
        query = Category.query
        if category_type:
            query = query.filter(Category.type == category_type)
        
        categories = query.order_by(Category.name).all()
        return jsonify([category.to_dict() for category in categories])
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@category_bp.route('/categories', methods=['POST'])
def create_category():
    """Criar nova categoria"""
    try:
        data = request.get_json()

        # Validação dos dados obrigatórios
        required_fields = ['name', 'type']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400

        # Validar tipo de categoria
        if data['type'] not in ['receita', 'despesa']:
            return jsonify({'error': 'Tipo deve ser "receita" ou "despesa"'}), 400

        # Verificar se categoria já existe
        existing_category = Category.query.filter_by(
            name=data['name'], 
            type=data['type']
        ).first()
        
        if existing_category:
            return jsonify({'error': 'Categoria já existe para este tipo'}), 400

        # Criar categoria
        category = Category(
            name=data['name'],
            type=data['type'],
            color=data.get('color', '#10B981'),
            icon=data.get('icon', 'DollarSign'),
            budget=data.get('budget')
        )

        db.session.add(category)
        db.session.commit()

        return jsonify(category.to_dict()), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@category_bp.route('/categories/<int:category_id>', methods=['GET'])
def get_category(category_id):
    """Obter categoria específica"""
    try:
        category = Category.query.get_or_404(category_id)
        return jsonify(category.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@category_bp.route('/categories/<int:category_id>', methods=['PUT'])
def update_category(category_id):
    """Atualizar categoria"""
    try:
        category = Category.query.get_or_404(category_id)
        data = request.get_json()

        # Atualizar campos se fornecidos
        if 'name' in data:
            # Verificar se novo nome já existe para o tipo
            existing_category = Category.query.filter_by(
                name=data['name'], 
                type=category.type
            ).filter(Category.id != category_id).first()
            
            if existing_category:
                return jsonify({'error': 'Categoria já existe para este tipo'}), 400
            
            category.name = data['name']
        
        if 'color' in data:
            category.color = data['color']
        
        if 'icon' in data:
            category.icon = data['icon']
        
        if 'budget' in data:
            category.budget = data['budget']
        
        if 'type' in data:
            if data['type'] not in ['receita', 'despesa']:
                return jsonify({'error': 'Tipo deve ser "receita" ou "despesa"'}), 400
            category.type = data['type']

        db.session.commit()
        return jsonify(category.to_dict())

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@category_bp.route('/categories/<int:category_id>', methods=['DELETE'])
def delete_category(category_id):
    """Deletar categoria"""
    try:
        category = Category.query.get_or_404(category_id)
        
        # Verificar se categoria tem transações associadas
        if category.transactions:
            return jsonify({
                'error': 'Não é possível deletar categoria com transações associadas'
            }), 400

        db.session.delete(category)
        db.session.commit()
        return jsonify({'message': 'Categoria deletada com sucesso'})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@category_bp.route('/categories/initialize', methods=['POST'])
def initialize_default_categories():
    """Criar categorias padrão do sistema"""
    try:
        # Categorias padrão de despesas
        default_expense_categories = [
            {'name': 'Alimentação', 'color': '#EF4444', 'icon': 'UtensilsCrossed'},
            {'name': 'Transporte', 'color': '#F59E0B', 'icon': 'Car'},
            {'name': 'Moradia', 'color': '#8B5CF6', 'icon': 'Home'},
            {'name': 'Saúde', 'color': '#EC4899', 'icon': 'Heart'},
            {'name': 'Educação', 'color': '#3B82F6', 'icon': 'GraduationCap'},
            {'name': 'Lazer', 'color': '#10B981', 'icon': 'Gamepad2'},
            {'name': 'Compras', 'color': '#F97316', 'icon': 'ShoppingBag'},
            {'name': 'Utilidades', 'color': '#6B7280', 'icon': 'Zap'},
            {'name': 'Outros', 'color': '#9CA3AF', 'icon': 'MoreHorizontal'}
        ]

        # Categorias padrão de receitas
        default_income_categories = [
            {'name': 'Salário', 'color': '#10B981', 'icon': 'Briefcase'},
            {'name': 'Freelance', 'color': '#3B82F6', 'icon': 'Laptop'},
            {'name': 'Investimentos', 'color': '#8B5CF6', 'icon': 'TrendingUp'},
            {'name': 'Vendas', 'color': '#F59E0B', 'icon': 'ShoppingCart'},
            {'name': 'Outros', 'color': '#6B7280', 'icon': 'Plus'}
        ]

        created_categories = []

        # Criar categorias de despesas
        for cat_data in default_expense_categories:
            existing = Category.query.filter_by(
                name=cat_data['name'], 
                type='despesa'
            ).first()
            
            if not existing:
                category = Category(
                    name=cat_data['name'],
                    type='despesa',
                    color=cat_data['color'],
                    icon=cat_data['icon']
                )
                db.session.add(category)
                created_categories.append(category)

        # Criar categorias de receitas
        for cat_data in default_income_categories:
            existing = Category.query.filter_by(
                name=cat_data['name'], 
                type='receita'
            ).first()
            
            if not existing:
                category = Category(
                    name=cat_data['name'],
                    type='receita',
                    color=cat_data['color'],
                    icon=cat_data['icon']
                )
                db.session.add(category)
                created_categories.append(category)

        db.session.commit()

        return jsonify({
            'message': f'{len(created_categories)} categorias padrão criadas',
            'categories': [cat.to_dict() for cat in created_categories]
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

